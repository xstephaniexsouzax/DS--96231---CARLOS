package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

// PRIMEIRO DIGITE ESSE CODIGO AQUI

//DEPOIS VA NO ISOMIA E FAÇA ISSSO AGORA
// COMO DEPOIS DO BARRA É O RETURN BEM VINDO, VAI APARECER NA TELA O BEM VINDO, VOU MOSTRAR O QUE EU JÁ FIZ E EXCLUIR ESSE DE AGORA

// SE EU MUDAR O NOME DEPOIS DA BARRA MUDA A "FUNÇÃO" E O RETORNO DELA

@RestController
public class Welcome {

    @GetMapping("/")
    public  String mensagem(){
        return "Bem - vindo!";
    }

    @GetMapping ("/dev")
    public String nomeDev(){
        return "Creaty by: Stephanie";
    }
}
